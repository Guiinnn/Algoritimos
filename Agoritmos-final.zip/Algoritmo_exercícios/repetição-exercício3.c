#include <stdio.h>

void inteiros( int n1, int n2)
{
    if(n1 < n2)
    {
        while(n1 <= n2)
        printf("%d\n", n1++);
    }
    else
    {
        while(n2 <= n1)
        printf("%d\n", n2++);
    }

}

int main()
{
    int d, e;

    printf("Digite dois numeros inteiros:");
    scanf("%d %d", &d, &e);
    inteiros(d,e);
    return 0;
}
