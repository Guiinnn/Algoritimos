#include <stdio.h>

void calculo(float y)
{
    int x = y;
    float custo;
    custo = 5000.00 + (55.00 * x) * 1.25;
    printf("\nO custo da producao sera de: %.2f", custo);
    float receita;
    receita = x * 102.00;
    printf("\nA eaceita referente a venda das pecas sera de: %.2f", receita);
    float lucro;
    lucro = receita - custo;
    printf("\nO lucro com a venda das pecas sera de: %.2f", lucro);
}

int main()
{
    int a;
    float custos;
    printf("Informe o numero de pecas a ser produzidas: ", a);
    scanf("%d", &a);
    calculo(a);
    return 0;
}
