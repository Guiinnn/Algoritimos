#include <stdio.h>

float aumento(int codigo, float salario)
{
    float novo_salario;

    if (codigo == 1)
    {
        novo_salario = salario * 1.5;
    }
    else if (codigo == 2)
    {
        novo_salario = salario * 1.3;
    }
    else if (codigo == 3)
    {
        novo_salario = salario * 1.2;
    }
    else //(codigo < 1 || codigo > 3);
    {
        printf("Codigo de cargo invalido! Nenhum almento aplicado.\n");
        novo_salario = salario;
    }
    return novo_salario;
}

int main()
{
    int a;
    float b, resultado;

    printf("Digite o codigo referente ao seu cargo: ");
    scanf("%d", &a);

    printf("Digite o valor referente ao seu salario: ");
    scanf("%f", &b);

    resultado = aumento(a, b);
    printf("Seu novo salario e: %.2f reais ", resultado);

    return 0;
}
