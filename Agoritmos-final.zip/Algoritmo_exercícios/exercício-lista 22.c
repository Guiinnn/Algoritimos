#include <stdio.h>

float operacao(float a, float b, char s)
{
    switch(s)
    {
        case '+': return a + b;
        break;
        case '-': return a - b;
        break;
        case '*': return a * b;
        break;
        case '/': return a / b;
        break;
        default:
            printf("Simbolo invalido!");
            return 0;
    }
}

int main()
{
    float a, b;
    char s;

    printf("Digite dois valores numericos e um simbolo que representa a operacao desejada: ");
    scanf("%f %f %c", &a,&b,&s);
    printf("O resultado da operacao e: %.2f", operacao(a,b,s));

    return 0;
}
