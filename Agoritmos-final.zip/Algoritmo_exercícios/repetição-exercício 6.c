#include <stdio.h>

int main()
{
    float c, z;
    c = 1.50;
    z = 1.40;

    int anos;

    while(z <= c)
    {
        c = c + 0.02;
        z = z + 0.03;
        anos++;
    }

    printf("Serao necessario %d anos.", anos);

    return 0;

}
