#include <stdio.h>

int main()
{
    int num1, num2, area, perimetro;

    printf("Digite o valor da base e da altura: ");

    scanf("%d %d", &num1, &num2);

    area = num1 * num2;
    perimetro = num1 + num1 + num2 + num2;

    printf("\n%d %d", area, perimetro);

    return 0;
}
