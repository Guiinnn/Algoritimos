#include <stdio.h>

int main()
{
    int num, soma = 0;

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &num);

    for (int a = 1; a < num; a++)
    {
        if (num % a == 0)
        {
            soma += a;
        }
    }

    printf("A soma dos divisores do numero %d e %d", num, soma);

    return 0;
}
