#include <stdio.h>

int main()
{
  float A = 3;
  float B = 7;
  float C = 4;

  printf("%d", (A + C) > B );
  printf("\n%d", B >=  (A + 2));
  printf("\n%d", C == (B - A));
  printf("\n%d", (B + A) <=  C);
  printf("\n%d", (C + A) > B );

  return 0;
}
