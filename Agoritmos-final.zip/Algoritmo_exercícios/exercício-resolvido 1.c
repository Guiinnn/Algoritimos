#include <stdio.h>

float mediade4num(int num1, int num2, int num3, int num4)
{
    float media;
    media = (num1 + num2 + num3 + num4) / 4.0;
    return media;
}

int main(void)
{
    int v1, v2, v3, v4;
    float media;
    printf("Informe 4 valores inteiros: ");
    scanf("%d %d %d %d", &v1, &v2, &v3, &v4);
    media = mediade4num(v1, v2, v3, v4);
    printf("A media e: %.2f", media);
    return 0;
}
