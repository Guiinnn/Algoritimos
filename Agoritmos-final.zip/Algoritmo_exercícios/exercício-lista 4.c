#include <stdio.h>
#include <math.h>

int main()
{
    float a, b, h;

    printf("Informe o valor do cateto a:");
    scanf("%f", &a);
    printf("Informe o valor do cateto b:");
    scanf("%f", &b);

    h = sqrt((a * a) + (b * b));

    printf("A hipotenusa e %.2f", h);

    return 0;
}
