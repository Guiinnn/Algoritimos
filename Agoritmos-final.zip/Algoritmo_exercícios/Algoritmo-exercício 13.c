#include <stdio.h>
#include <math.h>

int main()
{
    float C = 30000;
    float t = 0.1472;
    float T = 7;
    float M = C * pow((1 + t),T);

    printf("%.2f", M = C * pow((1 + t),T) );

    return 0;

}
