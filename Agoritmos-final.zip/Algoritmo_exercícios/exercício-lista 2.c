#include <stdio.h>

int main()
{
    float num1, num2, num3, num4, media;

    printf("Digite quatro valores reais: ");
    scanf("%f%f%f%f", &num1, &num2, &num3, &num4);

    media = (num1 + num2 + num3 + num4)/4;

    printf("A media e %.2f", media);

    return 0;
}
