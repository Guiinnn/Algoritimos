#include <stdio.h>

int main()
{
    float base, resultado = 1;
    int expoente;

    printf("Digite o valor da base:");
    scanf("%f", &base);
    printf("Digite o valor do expoente: ");
    scanf("%d", &expoente);

    for(int a = 1; a <= expoente; a++)
    {
        //resultado = base * base;
        resultado =  base * resultado;
    }

        printf("O resultado e %.2f: ", resultado);


    return 0;
}
