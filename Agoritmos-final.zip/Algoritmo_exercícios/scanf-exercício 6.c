#include <stdio.h>

int main()
{
    int num, inverso, d1, d2, d3;

    printf("Digite um numero inteiro que tenha 3 algarismos:");

    scanf("%d", &num);


    d1 = num / 100;
    d2 = (num % 100) / 10;
    d3 = num % 10;
    inverso = d3 * 100 + d2 * 10 + d1;

    printf("O numero na ordem inversa e: %d", inverso);

    return 0;
}
