#include <stdio.h>
#include <math.h>

float volume(float r)
{
    float resultado;
    resultado = (4 * 3.14 * pow(r,3) ) / 3;
    return resultado;
}

int main()
{
    float a;
    float resultado;
    printf("Digite o raio da esfera: ");
    scanf("%f", &a);
    resultado = volume(a);
    printf("O volume da esfera e: %.2f", resultado);

    return 0;
}
