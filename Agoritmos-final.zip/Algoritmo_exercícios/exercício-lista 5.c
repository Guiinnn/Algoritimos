#include <stdio.h>

int main()
{
    float a, b;

    printf("Digite dois numeros: ");
    scanf("%f%f", &a, &b);

    if(a < b)
    {
        printf("O maior numero e o %.2f", b);
    }
    else if(b < a)
    {
        printf("O maior numero e o %.2f", a);
    }
    else
    {
        printf("Numeros iguais.");
    }

    return 0;
}
