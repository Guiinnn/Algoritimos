#include <stdio.h>

int somaintervalo(int n1, int n2)
{
    int soma = 0;
    if(n1 < n2)
    {
        while(n1 <= n2)
        {
            soma =n1 + soma;
            n1++;
        }
    }
    else
    {
        while(n2 <= n1)
        {
            soma =n2 + soma;
            n2++;
        }
    }
    return soma;
}

int main()
{
    int a, b;

    printf("Digite dois valores inteiros: ");
    scanf("%d %d", &a, &b);
    printf("A soma e: %d", somaintervalo(a,b));
    return 0;
}
