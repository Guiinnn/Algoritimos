#include <stdio.h>

int main()
{
    int valor, menor;

    printf("Digite um valor (ou 0 para sair): ");
    scanf("%d", &valor);

    if (valor == 0)
    {
        printf("Nenhum valor informado.\n");
        return 0;
    }

    menor = valor;

    while(valor != 0)
    {
        if(valor < menor) menor = valor;

        printf("Digite o proximo valor (ou 0 para sair):");
        scanf("%d", &valor);
    }

    printf("O menor valor digitado foi: %d\n", menor);

    return 0;
}
