#include <stdio.h>

int main()
{
    float C = 21;
    float F;
    F = (9 * C + 160) / 5;
    printf("%.1f F\n", F);
    return 0;
}
