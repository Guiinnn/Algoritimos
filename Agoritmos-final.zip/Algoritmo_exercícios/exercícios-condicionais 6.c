#include <stdio.h>

int comprimentos(int x, int y, int z)
{
    if ( x < y + z && y < x + z && z < x + y)
    {
        printf("Os comprimentos formam um triangulo");
    }
    else
    {
        printf("Os comprimentos nao formam um triangulo");
    }
}

int main()
{
    int a, b, c;
    int resultado;

    printf("Digite 3 valores inteiros: ");
    scanf("%d %d %d", &a, &b, &c);

    resultado = comprimentos(a, b, c);

    return 0;
}
