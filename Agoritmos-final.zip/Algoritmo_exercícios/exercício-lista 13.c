#include <stdio.h>

int main()
{
    int num, contador = 1;
    float  media = 0;

    printf("Informe 10 numeros inteiros positivos: \n");

    while(contador <= 10)
        {
            scanf("%d", &num);

            if (num >= 0)
            {
                 media += num;
                 contador++;
            }
            else
            {
                printf("Numero invalido!Digite outro:\n");
            }
        }

    media = media/10.;

    printf("A media dos 10 numeros informados e %.2f", media);

    return 0;
}
