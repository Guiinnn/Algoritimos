#include <stdio.h>

void divisivel(int n)
{
    if(n%6 == 0)
    {
      printf("O numero %d eh divisivel por 2 e 3.", n);
    }
    else
    {
        printf("O numero %d nao eh divisivel por 2 e 3.", n);
    }
}
int main()
{
    divisivel(4);

    return 0;
}
