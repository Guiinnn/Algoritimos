#include <stdio.h>

int main()
{
    float D = 110;
    float T = 1.83;
    float VM = D/T;

    printf("%.2f Km/h", VM);

    return 0;
}
