#include <stdio.h>

int main()
{
    int N, fatorial = 1;
    float E = 0;

    printf("Informe um valor inteiro e positivo: ");
    scanf("%d", &N);

    for(int a = 1; a <= N; a++)
    {
        fatorial = fatorial * a;
        E = E + (1./fatorial);
    }
    printf("E = %.2f", E);

    return 0;
}
