#include <stdio.h>


int main()
{
    int contador = 0;

    while (contador <= 100)
    {
        printf("%d\n", contador);
        contador = contador + 2;
    }

    return 0;
}
