#include <stdio.h>

int main()
{
    int n, a = 1;
    float media = 0;

    printf("Informe 10 numeros inteiros e positivo: ");

    while (a <= 10)
    {
        scanf("%d", &n);
        printf("Proximo numero: ");

        if(n >= 0)
        {
            media += n;
            a++;
        }
        else
        {
            printf("Numero invalido, digite outro.\n");
        }
    }

    media = media/10.;
    printf("O valor da media e %.2f", media);

    return 0;
}
