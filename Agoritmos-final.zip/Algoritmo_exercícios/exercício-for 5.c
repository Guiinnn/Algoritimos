#include <stdio.h>

int somaintervalo(int n1,int n2)
{
    int resultado = 0;

    for(; n1 <= n2; n1++)
    {
        resultado = resultado + n1;
        //printf("%d\n", resultado);
    }

    for(; n2 <= n1; n2++)
    {
        resultado = resultado + n2;
        //printf("%d\n", resultado);
    }

    return resultado;
}

int main()
{
    int a, b;

    printf("Digite dois numeros inteiros: ");
    scanf("%d %d", &a, &b);

    printf("O resultado e %d ", somaintervalo(a,b));

    return 0;
}
