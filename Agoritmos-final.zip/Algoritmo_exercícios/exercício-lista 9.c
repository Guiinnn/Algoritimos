#include <stdio.h>

int main()
{
    int num, num2 = 0;

    printf("Informe um numero inteiro: ");
    scanf("%d", &num);

    while (num2 <= num)
    {
        printf("%d\n", num2);
        num2++;
    }

    return 0;
}
