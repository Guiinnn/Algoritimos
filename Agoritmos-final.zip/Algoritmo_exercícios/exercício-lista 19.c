#include <stdio.h>

int main()
{
    int num;

    printf("Informe um numero: ");
    scanf("%d", &num);

    for (;123 != num;)
    {
        printf("Informe um numero: ");
        scanf("%d", &num);
    }
    return 0;
}
