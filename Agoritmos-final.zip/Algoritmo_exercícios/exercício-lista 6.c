#include <stdio.h>

int main()
{
    float salario, divida;

    printf("Informe o valor do seu salario: ");
    scanf("%f", &salario);
    printf("Informe o valor da presta��o do emprestimo: ");
    scanf("%f", &divida);

    if(divida > 0.2 * salario)
    {
        printf("Emprestimo nao concedido.");
    }
    else
    {
        ("Emprestimo concedido");
    }

    return 0;
}
