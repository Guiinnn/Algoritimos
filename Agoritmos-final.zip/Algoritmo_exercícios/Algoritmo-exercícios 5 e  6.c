#include<stdio.h>

int main ()
{
    printf( "Mariana");
    printf("\n%d",18);
    printf("\n%.2f",1.50);
    return 0;
}
