#include <stdio.h>

float imc(float peso, float metros)
{
    float IMC = peso/(metros * metros);

    return IMC;
}

int main()
{
    float b;
    float a;

    printf("Informe a sua altura em metros: ");
    scanf("%f", &b);
    printf("Informe o seu peso em quilos: ");
    scanf("%f", &a);

    printf("Seu IMC e %.2f Kg/m", imc(a,b));

    return 0;
}
