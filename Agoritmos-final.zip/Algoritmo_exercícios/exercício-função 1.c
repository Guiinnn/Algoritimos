#include <stdio.h>

void produtos(int num1, int num2)
{
    int produto;
    produto = num1 * num2;
    printf("O produto e: %d", produto);
}

int main(void)
{
    int n1, n2;
    int produto;
    printf("Digite dois numeros inteiros: ");
    scanf("%d %d", &n1, &n2);
    produtos(n1, n2);
    /*produto = produtos(n1, n2);
    printf("O produto e: %d", produto;
    */return 0;
}
