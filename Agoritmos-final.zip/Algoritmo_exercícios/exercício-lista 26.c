#include <stdio.h>

void inteiros(int n)
{
    if(n < 0)
    {
        return;
    }
    else
    {
        inteiros(n-1);
        printf("%d ", n);
    }
}

int main()
{
    int n;

    printf("Digite um numero inteiro: ");
    scanf("%d", &n);
    printf("A ordem crescente de 0 ate %d e:", n);
    inteiros(n);
    printf("\n");

    return 0;
}
