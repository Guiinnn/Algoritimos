#include <stdio.h>

int main()
{
    int valor, menor;

    printf("Digite um valor (ou 0 para encerrar):");
    scanf("%d", &valor);

    if(valor == 0)
    {
        printf("Nenhum valor informado.");
        return 0;
    }
    menor = valor;


    for(; valor != 0; )
    {
        if(valor < menor)
        {
            menor = valor;
        }

        printf("Digite um valor (ou 0 para encerrar):");
        scanf("%d", &valor);
    }

    printf("O menor valor informado e %d.\n", menor);

    return 0;
}
