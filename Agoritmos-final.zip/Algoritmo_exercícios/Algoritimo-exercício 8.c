#include <stdio.h>

int main()
{
    float H;
    H = (1 + 1.0/2.0 + 1.0/3.0 + 1.0/4.0 + 1.0/5.0);
    printf("%f", H);
    return 0;
}
