#include <stdio.h>

char mediafinal(float n)
{
    if (n >= 0 && n <= 49)
    {
       return 'D';
    }
    else if (n >= 50 && n <= 69)
    {
       return 'C';
    }
    else if (n >= 70 && n <= 89)
    {
       return 'B';
    }
    else if (n >= 90 && n <= 100)
    {
        return 'A';
    }
    else
    {
       return 'I';
    }
}

int main()
{
    float a;
    char resultado;

    printf("Digite sua nota media final: ");
    scanf("%f", &a);

    resultado = mediafinal(a);
    if (resultado == 'I')
    {
        printf("Nota invalida! Nenhum conceito foi aplicado. ");
    }
    else
    {
        printf("Seu conceito e: %c", resultado);
    }

    return 0;
}
