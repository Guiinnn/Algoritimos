#include <stdio.h>

//chico = 150cm + 2cm/ano
//ze = 140cm + 3cm/ano
//z > c

int main()
{
    int z = 150, c = 140, ano;

    for( ano = 0; c <= z; ano++)
    {
        z += 2;
        c += 3;
    }

    printf("Sera necessario %d anos.", ano);

    return 0;
}
