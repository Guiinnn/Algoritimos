#include <stdio.h>
#include <math.h>

void IMC(float p, float q)
{
    float resultado;
    resultado = p / pow(q,2);
    printf("Seu IMC e: %.2f", resultado);
}

int main(void)
{
    float a, b;
    float resultado;
    printf("Digite seu peso, em quilogramas, e a sua altura, em metros: ");
    scanf("%f%f", &a, &b);
    IMC(a, b);
    return 0;
}
