#include <stdio.h>

int main()
{
    int idade;

    printf("Informe sua idade: ");
    scanf("%d", &idade);

    switch(idade)
    {
        case 5:
        case 6:
        case 7:
            printf("Categoria Infantil A");
            break;
        case 8:
        case 9:
        case 10:
            printf("Categoria Infantil B");
            break;
        case 11:
        case 12:
        case 13:
            printf("Categoria Juvenil A");
            break;
        case 14:
        case 15:
        case 16:
        case 17:
            printf("Categoria Juvenil B");
    }

    if (idade >= 18)
    {
        printf("Categoria Senior");
    }

    return 0;
}
