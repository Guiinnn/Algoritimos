#include <stdio.h>

int main()
{
    int a, b, result;

    printf("Informe dois numeros: ");
    scanf("%d %d", &a, &b);

    if (b!=0)
    {
        float result = a/(float)b;
        printf("O resultado e %f.", result);
    }
    else
    {
        printf("O segundo numero deve ser diferente de zero.");
    }
    return 0;
}
