#include <stdio.h>

float positivo(int n1)
{
    float s = 0;
    while(n1 > 0)
    {
       s = s + (1.0/n1);
       n1--;
    }
    return s;
}

int main()
{
    int a;
    printf("Digite um numero inteiro: ");
    scanf("%d", &a);
    printf("O valor de S e: %.2f", positivo(a));

    return 0;
}
