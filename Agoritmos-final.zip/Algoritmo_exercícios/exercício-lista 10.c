#include <stdio.h>

int main()
{
   int n;

   printf("Informe um numero inteiro: ");
   scanf("%d", &n);
   printf("A ordem decrescente e:\n");

   for(; n >= 0; n--)
   {
       printf("%d\n", n);
   }

   return 0;
}
