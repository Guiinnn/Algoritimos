#include <stdio.h>

int inteiros(int num1, int num2)
{

    for(; num1 <= num2; num1++)
    {
        printf("%d\n", num1);
    }

    for(; num2 <= num1; num2++)
    {
        printf("%d\n", num2);
    }

    return 0;
}

int main()
{
    int a, b;

    printf("Digite dois numeros inteiros: ");
    scanf("%d %d", &a, &b);
    inteiros(a,b);


    return 0;
}
