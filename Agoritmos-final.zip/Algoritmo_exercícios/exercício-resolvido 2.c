#include <stdio.h>

float convercao(float c1)
{
    float temperatura;
    temperatura = c1 * 1.8 + 32;
    return temperatura;
}

int main(void)
{
    float c1;
    float temperatura;
    printf("Informe a temperatura em graus Celsius: ");
    scanf("%f", &c1);
    temperatura = convercao(c1);
    printf("A temperatura em Fahrenheit e: %.2f", temperatura);
    return 0;
}
