#include <stdio.h>

int main()
{
    int p, a = 1;
    // se for usar o While o contador deve aparecer aqui:
    int contador = 1;

    printf("Informe um numero inteiro positivo: ");
    scanf("%d", &p);
    printf("Os %d numeros naturais impares sao:\n", p);

    while(contador <= p)
    {
        printf("%d\n", a);
        a = a +2;
        contador++;
    }



    /*for(int contador = 1; contador <= p; contador++)
    {
        printf("%d\n", a);
        a = a + 2;
    }
    */

    return 0;
}
