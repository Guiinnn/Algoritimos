#include <stdio.h>

int inteiros(int n)
{
    if(n <= 1)
    {
        return 1;
    }
    else
    {
        return n + inteiros(n - 1);
    }
}

int main()
{
    int n;
    printf("Informe um valor inteiro positivo:");
    scanf("%d", &n);
    printf("O somatorio dos numeros de %d ate 1 e: %d", n, inteiros(n));

    return 0;
}
