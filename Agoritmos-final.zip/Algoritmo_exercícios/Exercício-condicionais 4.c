#include <stdio.h>

void reais(float a, float b)
{
    if(a>0 && b>0)
    {
        printf("Valores sao validos", a, b);
    }
    else
    {
        printf("Valores invalidos", a, b);
    }
}

int main()
{
    reais(1, 13.8);

    return 0;
}
