#include <stdio.h>

int main()
{
    int num, soma, subtracao;

    printf(" Digite um valor inteiro: ");

    scanf("%d", &num);

    soma = num + 1;
    subtracao = num - 1;

    printf("\n%d %d", soma, subtracao);

    return 0;
}
