#include <stdio.h>

int main()
{
    int p = 0, somafinal = 0;

    printf("A soma dos 50 primeiros numeros pares e:\n");

    for (int contador = 1; contador <= 50; contador++)
    {
        p = p + 2;
        somafinal += p;

    }
    printf("%d", somafinal);

    return 0;
}
