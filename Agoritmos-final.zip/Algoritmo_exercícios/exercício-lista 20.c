#include <stdio.h>

float maior(float num1, float num2)
{
    if (num1 > num2)
    {
        return num1;
    }
    else
    {
        return num2;
    }
}

int main()
{
    float a, b;

    printf("Informe dois numeros: ");
    scanf("%f %f", &a, &b);

    printf("O maior e %f", maior(a,b));

    return 0;
}
