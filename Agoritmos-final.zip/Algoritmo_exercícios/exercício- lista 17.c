#include <stdio.h>

int main()
{
    int num = 1, linhas;

    printf("Informe o numero de linhas: ");
    scanf("%d",&linhas);

    for(int linha = 1; linha <= linhas; linha = linha + 1)
    {
        //repeti��o para controlar a impress�o nos numeros
        //em cada linhs
        for(int n = 1;n <= linha; n = n + 1)
            {
                printf("%d ",num);
                num = num + 1;
            }

        printf("\n");
    }

    return 0;
}
