#include <stdio.h>

float positivo(int n)
{
    float resultado = 0;

    for(; n > 0; n--)
    {
        resultado = resultado + (1./n);
    }

    return resultado;
}

int main()
{
    int a ;

    printf("Digite um numero inteiro e positivo: ");
    scanf("%d", &a);
    printf("O resultado e %.2f", positivo(a));

    return 0;
}
