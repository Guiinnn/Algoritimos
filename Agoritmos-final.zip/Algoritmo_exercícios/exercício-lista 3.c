#include <stdio.h>

int main()
{
    int idade, anoatual, ano;

    printf("Informe sua idade:");
    scanf("%d", &idade);
    printf("Informe o ano atual:");
    scanf("%d", &anoatual);

    ano = anoatual - idade;

    printf("O seu ano de nascimento e %d.", ano);

    return 0;
}
