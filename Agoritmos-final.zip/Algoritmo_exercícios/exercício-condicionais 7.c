#include <stdio.h>

int dia(int x)
{
    if (x == 1)
    {
     printf("Domingo ");
    }
     if (x == 2)
     {
         printf("Segunda-feira ");
     }
     if (x == 3)
     {
         printf("Terca-feira ");
     }
     if (x == 4)
     {
         printf("Quarta-feira ");
     }
     if (x == 5)
     {
         printf("Quinta-feira ");
     }
     if (x == 6)
     {
         printf("Sexta-feira ");
     }
     if (x == 7)
     {
         printf("Sabado ");
     }
     if (x < 1 || x > 7)
     {
         printf("Dia da semana invalido");
     }
}

int main()
{
    int a, resultado;

    printf("Digite o numero do dia da semana: ");
    scanf("%d",&a);

    resultado = dia(a);

    return 0;
}
