#include <stdio.h>

int main()
{
    char letra;

    printf("Digite uma letra: ");
    scanf("%c", &letra);

    switch (letra)
    {
    case 'a':
        printf("A letra informada e uma vogal.");
        break;
    case 'e':
        printf("A letra informada e uma vogal.");
        break;
    case 'i':
        printf("A letra informada e uma vogal.");
        break;
    case 'o':
        printf("A letra informada e uma vogal.");
        break;
    case 'u':
        printf("A letra informada e uma vogal.");
        break;
    default:
        printf("A letra informada e uma consoante.");
        break;
    }
    return 0;
}
