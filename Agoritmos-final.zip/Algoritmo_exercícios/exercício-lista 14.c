#include <stdio.h>

int main()
{
    int num;

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &num);

    for(int a = 1; a <= num; a++)
    {
        if (num % a == 0)
        {
            printf("%d\n", a);
        }
    }
    return 0;

}
