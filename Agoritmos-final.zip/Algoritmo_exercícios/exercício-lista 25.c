#include <stdio.h>

int fatorial(int n)
{
    if (n <= 1)
    {
        return 1;
    }
    else
    {
        return n * fatorial(n - 1);
    }
}

int main()
{
    int n;

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &n);
    printf("O fatorialde %d! e: %d", n, fatorial(n));

    return 0;
}
