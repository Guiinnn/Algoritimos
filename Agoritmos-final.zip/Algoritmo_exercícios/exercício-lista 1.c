#include <stdio.h>

int main()
{
    float real, resultado;

    printf("Digite um numero real:");
    scanf("%f", &real);

    resultado = real / 5.;

    printf("A quinta parte do numero informado e %.2f.", resultado);

    return 0;
}
