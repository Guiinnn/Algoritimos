#include <stdio.h>

int main()
{
    int dia;

    printf("Informe um numero de 1 a 7: ");
    scanf("%d",&dia);

    switch(dia)
{
case 1:
    printf("Domingo");
    break;
case 2:
    printf("Segunda-feira");
    break;
case 3:
    printf("Terca-feira");
    break;
case 4:
    printf("Quarta-feira");
    break;
case 5:
    printf("Quinta-feira");
    break;
case 6:
    printf("Sexta-feira");
    break;
case 7:
    printf("Sabado");
    break;
default:
    printf("Dia da semana invalido!");
}
    /*if(dia == 1) printf("Domingo");
    else if(dia == 2) printf("Segunda-feira");
    else if(dia == 3) printf("Terca-feira");
    else if(dia == 4) printf("Quarta-feira");
    else if(dia == 5) printf("Quinta-feira");
    else if(dia == 6) printf("Sexta-feira");
    else if(dia == 7) printf("Sabado");
    else printf("Dia da semana invalido!");
*/
    return 0;
}
