#include <stdio.h>

void divisivel(int n)
{
    /*int n;
    printf("Informe um numero inteiro: ");
    scanf("%d", &n);

    */if(n%2 == 0)
    {
      printf("O numero %d eh divisivel po 2.", n);
    }
    else
    {
        printf("O numero %d nao eh divisivel por 2.", n);
    }
}

int main()
{
    divisivel(4);

    return 0;
}
