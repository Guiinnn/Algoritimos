#include <stdio.h>

int main()
{
    int nota1, nota2, nota3, mp;

    printf("Informe suas 3 notas: ");

    scanf("%d %d %d", &nota1, &nota2, &nota3);

    mp = (nota1*2) + (nota2*3) + (nota3*5);

    printf("A media ponderada de suas notas e: %d", mp);

    return 0;
}
