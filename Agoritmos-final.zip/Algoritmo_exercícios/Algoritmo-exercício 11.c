#include <stdio.h>

int main()
{
    float A = 2;
    float B = 7;
    float C = 3.5;
    float L1 = 0;

    printf("%d", B == A*C && L1);
    printf("\n%d", A + C < 5);
    printf("\n%d", A*C/B > A*B*C );
    printf("\n%d", ! 'FALSO');

    return 0;

}
