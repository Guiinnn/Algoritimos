#include <stdio.h>

int main()
{
    int num, contador = 1;

    printf("Digite um numero inteiro e positivo: ");
    scanf("%d", &num);

    for(int a = 1; a <= num; a++)
    {
        for(int b = 1; b <= a; b++)
        {
            printf("%d ", contador);
            contador++;
        }
        printf("\n");
    }
    return 0;
}
