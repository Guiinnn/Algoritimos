#include <stdio.h>

int main()
{
    float num1, despesas, gorjeta;

    printf("Digite o valor das despesas: ");

    scanf("%f", &num1);

    despesas = num1 + 0.1 * num1;

    printf("Valor total da conta: %.2f", despesas);

    return 0;
}
