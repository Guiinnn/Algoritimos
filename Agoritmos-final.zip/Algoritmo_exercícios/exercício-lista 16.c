#include <stdio.h>

int main()
{
    int num, a = 0, b = 1, proximo;

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &num);

    if (num == 0)
    {
        printf("O termo e: %d\n", a);
    }
    else if (num == 1)
    {
        printf("O termo e: %d\n", b);
    }
    else
    {
        for(int i = 2; i <= num; i++)
        {
            proximo = a + b;
            a = b;
            b = proximo;
        }
        printf("O termo na posicao %d e: %d\n", num, b);
    }

    return 0;
}
