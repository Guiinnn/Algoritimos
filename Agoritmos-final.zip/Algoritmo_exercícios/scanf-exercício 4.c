#include <stdio.h>

int main()
{
    int horas, minutos, resultado;

    printf("Digite a hora e o minuto atual:");

    scanf("%d %d", &horas, &minutos);

    resultado = (horas * 60) + minutos;

    printf("Os minutos passados desde o in�cio do dia s�o: %d\n ", resultado);

    return 0;
}
