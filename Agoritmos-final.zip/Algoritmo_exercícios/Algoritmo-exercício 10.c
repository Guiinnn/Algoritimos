#include <stdio.h>

int main()
{
    float A = 5;
    float B = 4;
    float C = 3;
    float D = 6;

    printf("%d", (A > C) && (C <=  D));
    printf("\n%d", (A + B) > 10 || (A + B) == (C + D));
    printf("\n%d", (A >= C) && (D >= C));

    return 0;

}
