#include <stdio.h>
#include <math.h>

int soma(int n)
{
    if (n <= 1)
    {
        return 1;
    }
    else
    {
        return pow(n, 3) + soma(n - 1);
    }
}

int main()
{
    int n;

    printf("Digite um numero: ");
    scanf("%d", &n);
    printf("A soma dos %d numeros ao cubo e: %d", n, soma(n));

    return 0;
}
