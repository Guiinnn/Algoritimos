#include <stdio.h>

int main()
{
   char nome[50], naturalidade[50];
   int idade;
   float altura;

   //setbuf(stdout, NULL);

   printf("Informe seu nome, sua naturalidade, sua idade e sua altura:");

   gets(nome);
   gets(naturalidade);

   scanf("%d %f", &idade, &altura);
   puts(nome);
   puts(naturalidade);

   printf("%d", idade);
   printf("\n%f", altura);

    return 0;
}
