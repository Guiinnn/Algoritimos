#include <stdio.h>

float peso_ideal(float h , char sexo )
{
   if (sexo == 'M' || sexo == 'm')
   {
       return  (72.7 * h) - 58;
   }
   else if (sexo == 'F' || sexo == 'f')
   {
       return (62.1 * h) - 44.7;
   }
   else
   {
       return 0;
   }
}

int main()
{
    float H, resultado;
    char s;

    printf("Digite sua altura e o seu sexo: ");
    scanf("%f %c ", &H, &s);

    resultado = peso_ideal(H, s);

    printf("O seu peso ideal e: %.2f kg", resultado);

    return 0;
}
