#include <stdio.h>

void mp(float n1, float n2, float n3)
{
    float resultado;
    resultado = (n1 * 2 + n2 * 3 + n3 * 5.) / (2. + 3. + 5.);
    printf("A media ponderada e: %.2f", resultado);
}

int main(void)
{
    float a, b, c;
    float resultado;
    printf("Digite as suas 3 notas: ");
    scanf("%f%f%f", &a, &b, &c);
    mp(a, b, c);
    return 0;
}
