#include <stdio.h>

void tempo(int num)
{
    int h, m, s;
    h = num / 3600;
    m = (num % 3600) / 60;
    s = num % 60;

    printf("O tempo e: %d:%d:%d", h, m, s);
}

int main(void)
{
    int a;
    int h, m, s;
    printf("Digite o tempo em segundos: ");
    scanf("%d", &a);
    tempo(a);

    return 0;
}
