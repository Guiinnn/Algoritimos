#include <stdio.h>

void tempo(int segundos)
{
    int h, m;
    h = segundos/3600;
    segundos = segundos%3600;
    m = segundos/60;
    segundos = segundos%60;
    printf("%d:%d:%d",h,m,segundos);
}

int main()
{
    //tempo(7296);
    int a;
    int h, m, segundos;
    printf("Digite o tempo em segundos: ");
    scanf("%d", &a);
    tempo(a);

    return 0;
}
