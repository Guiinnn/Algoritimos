#include <stdio.h>

int main()
{
    int nota;

    printf("Digite uma nota de 0 a 10: ");
    scanf("%d", &nota);

    switch (nota)
    {
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
        printf("Ruim");
        break;
    case 5:
    case 6:
        printf("Regular");
        break;
    case 7:
    case 8:
        printf("Bom");
        break;
    case 9:
    case 10:
        printf("Excelent");
        break;
    default:
        printf("Classificacao nao encontarda.");
    }
    return 0 ;
}
